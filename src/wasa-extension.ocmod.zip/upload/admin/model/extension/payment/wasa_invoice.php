<?php
class ModelExtensionPaymentWasaInvoice extends Model
{
    public function install()
    {
        //
    }

    public function uninstall()
    {
        //
    }
}
