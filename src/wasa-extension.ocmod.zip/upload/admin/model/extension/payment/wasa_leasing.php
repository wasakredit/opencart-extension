<?php
class ModelExtensionPaymentWasaLeasing extends Model
{
    public function install()
    {
        //
    }

    public function uninstall()
    {
        //
    }
}
