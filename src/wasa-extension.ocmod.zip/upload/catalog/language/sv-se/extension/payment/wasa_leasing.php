<?php

// Text
$_['text_title'] = 'Wasa Kredit Leasing';
$_['text_test_mode'] = 'Wasa Kredit Leasing är i testläge!';

// Error
$_['error_currency'] = 'Wasa Kredit Leasing är bara tillgänglig för beställningar med valutan SEK';
