<?php

// Text
$_['text_title'] = 'Wasa Kredit Faktura';
$_['text_test_mode'] = 'Wasa Kredit Faktura är i testläge!';

// Error
$_['error_currency'] = 'Wasa Kredit Faktura är bara tillgänglig för beställningar med valutan SEK';
