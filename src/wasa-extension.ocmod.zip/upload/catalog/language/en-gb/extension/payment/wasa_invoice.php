<?php

// Text
$_['text_title'] = 'Wasa Kredit Invoice';
$_['text_test_mode'] = 'Wasa Kredit Invoice is in test mode!';

// Error
$_['error_currency'] = 'Wasa Kredit Invoice is only available for orders with the currency SEK';
