<?php

// Text
$_['text_title'] = 'Wasa Kredit Leasing';
$_['text_test_mode'] = 'Wasa Kredit Leasing is in test mode!';

// Error
$_['error_currency'] = 'Wasa Kredit Leasing is only available for orders with the currency SEK';
