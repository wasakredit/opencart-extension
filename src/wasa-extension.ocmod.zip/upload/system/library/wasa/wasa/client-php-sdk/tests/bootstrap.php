<?php

require_once dirname(__FILE__).'/../sdk/Response.php';
require_once dirname(__FILE__).'/../sdk/AccessToken.php';
require_once dirname(__FILE__).'/../sdk/Client.php';
require_once dirname(__FILE__).'/../sdk/Api.php';
require_once dirname(__FILE__).'/../config.php';