<?php return array(
    'root' => array(
        'pretty_version' => 'dev-master',
        'version' => 'dev-master',
        'type' => 'library',
        'install_path' => __DIR__ . '/../../../../../',
        'aliases' => array(),
        'reference' => 'ac9fef3715ad82dddfb2ee9dd0255c2ab479bc78',
        'name' => 'wasa/opencart-extension',
        'dev' => true,
    ),
    'versions' => array(
        'wasa/client-php-sdk' => array(
            'pretty_version' => 'dev-master',
            'version' => 'dev-master',
            'type' => 'library',
            'install_path' => __DIR__ . '/../wasa/client-php-sdk',
            'aliases' => array(
                0 => '9999999-dev',
            ),
            'reference' => 'a8eca895c63e531825fa291e8c4898dbe782635b',
            'dev_requirement' => false,
        ),
        'wasa/opencart-extension' => array(
            'pretty_version' => 'dev-master',
            'version' => 'dev-master',
            'type' => 'library',
            'install_path' => __DIR__ . '/../../../../../',
            'aliases' => array(),
            'reference' => 'ac9fef3715ad82dddfb2ee9dd0255c2ab479bc78',
            'dev_requirement' => false,
        ),
    ),
);
